<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

printf(
	'<div class="edukul-icon-list clearfix">%1$s</div>',
	do_shortcode($content)
);