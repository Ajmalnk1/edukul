<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$html = '';

extract( shortcode_atts( array(
	'image' => '',
	'text' => '',
	'name' => 'JOHN JOE',
	'position' => 'Sale Manager',
), $atts ) );

if ( $text )
$html .= sprintf(
	'<blockquote class="text">%1$s</blockquote>',
	$text
);

if ( $image ) {
    $html .= sprintf(
        '<div class="thumb">%1$s</div>',
         wp_get_attachment_image( $image, 'full' )
    );
}

if ( $name )
$html .= sprintf(
	'<h5 class="name">%1$s</h5>',
	$name
);

if ( $position )
$html .= sprintf(
    '<span class="position">%1$s</span>',
    $position
);

printf(
    '<div class="edukul-testimonials clearfix">
        %1$s
    </div>', 
    $html
);