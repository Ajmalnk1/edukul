<?php get_header();

$location = edukul_metabox('event_location');
$date = edukul_metabox('event_date');
$time = edukul_metabox('event_time');
$phone = edukul_metabox('event_phone');
?>

<div id="content-wrap" class="edukul-container">
    <div id="site-content" class="site-content single-event clearfix">
        <div id="inner-content" class="inner-content-wrap">

			<div class="event-detail-wrap">
				<?php while ( have_posts() ) : the_post(); ?>
		            <div id="event-description">
		                <?php the_content(); ?>
		            </div><!-- /entry-content -->

		            <div id="event-info">
						<h4 class="title">
		                    <?php echo esc_html__( 'Event Info', 'edukul' ); ?>
		                </h4>
						<ul>
							<li>
								<span><?php esc_html_e( 'Location:', 'edukul' ); ?></span>
								<span><?php echo $location; ?></span>
							</li>
							<li>
								<span><?php esc_html_e( 'Date:', 'edukul' ); ?></span>
								<span><?php echo $date; ?></span>
							</li>
							<li>
								<span><?php esc_html_e( 'Time:', 'edukul' ); ?></span>
								<span><?php echo $time; ?></span>
							</li>
							<li>
								<span><?php esc_html_e( 'Phone:', 'edukul' ); ?></span>
								<span><?php echo $phone; ?></span>
							</li>
						</ul>
		            </div>
				<?php endwhile; ?>
			</div>

        </div><!-- /#inner-content -->
    </div><!-- /#site-content -->
</div><!-- /#content-wrap -->

<?php get_footer(); ?>