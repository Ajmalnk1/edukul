<?php 
/*
Plugin Name: WPRT Custom Post Type
Plugin URI: http://rollthemes.com/plugins
Description: This plugin register Custom Post Type.
Version: 3.6.8
Author: RollThemes
Author URI: http://RollThemes.com
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'WPRT_CPT' ) ) {
	class WPRT_CPT {
		function __construct() {
			require_once dirname( __FILE__ ) . '/gallery.php';
			require_once dirname( __FILE__ ) . '/gallery-config.php';
			
			require_once dirname( __FILE__ ) . '/testimonials.php';
			require_once dirname( __FILE__ ) . '/partner.php';
			require_once dirname( __FILE__ ) . '/event.php';

			add_filter( 'single_template', array( $this,'edukul_single_gallery' ) );
			add_filter( 'single_template', array( $this,'edukul_single_event' ) );
	    }

		function edukul_single_gallery( $single_template ) {
			global $post;
			if ( $post->post_type == 'gallery' ) $single_template = dirname( __FILE__ ) . '/inc/single-gallery.php';
			return $single_template;
		}

		function edukul_single_event( $single_template ) {
			global $post;
			if ( $post->post_type == 'event' ) $single_template = dirname( __FILE__ ) . '/inc/single-event.php';
			return $single_template;
		}
	}
}
new WPRT_CPT;